import {
  withConfiguration,
} from '@pega/cosmos-react-core';

import type { PConnFieldProps } from './PConnProps';
import './create-nonce';

import StyledDjcsMyLibInputLabelWrapper from './styles';

// interface for props
interface DjcsMyLibInputLabelProps extends PConnFieldProps {
  label: string;
}

function DjcsMyLibInputLabel(props: DjcsMyLibInputLabelProps) {
  const { label } = props;


  return (
    <StyledDjcsMyLibInputLabelWrapper>

      <div>
        <label style={{fontWeight: 600, color: 'rgba(0, 0, 0, 0.6)', maxWidth: 'max-content', fontSize: 'max(0.8125rem, 12px)'}}>
          {label}
        </label>
      </div>

    </StyledDjcsMyLibInputLabelWrapper>
  );
};


export default withConfiguration(DjcsMyLibInputLabel);
